sudo mn --custom single3.py --topo single3 --mac --switch ovsk --controller remote --pre single3gateways.py -x
